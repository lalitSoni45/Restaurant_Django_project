# Feane Restaurant Website

A Django-powered restaurant website with menu management, table booking, and feedback functionality.

## Features

- Menu display with categories
- Table booking system
- Customer feedback form
- Admin panel for content management
- Responsive design

## Requirements

- Python 3.8+
- Django 5.2+
- Pillow (for image handling)

## Installation

1. Clone the repository:
```
git clone <repository-url>
cd my_restaurant
```

2. Create and activate a virtual environment:
```
# On Windows
python -m venv myenv
myenv\Scripts\activate

# On macOS/Linux
python3 -m venv myenv
source myenv/bin/activate
```

3. Install dependencies:
```
pip install django pillow
```

4. Apply migrations:
```
python manage.py makemigrations
python manage.py migrate
```

5. Create a superuser:
```
python manage.py createsuperuser
```

6. Create initial data:
```
python create_contact.py
python create_sample_data.py
```

7. Run the development server:
```
python manage.py runserver
```

8. Access the website at http://127.0.0.1:8000/

## Admin Access

Access the admin panel at http://127.0.0.1:8000/admin/ using the superuser credentials created in step 5.

## Folder Structure

- `base_app/` - Main application
  - `models.py` - Database models
  - `views.py` - View functions
  - `forms.py` - Form definitions
  - `admin.py` - Admin panel configuration
- `my_restaurant/` - Project settings
  - `Templates/` - HTML templates
  - `Static/` - Static files (CSS, JS, images)
  - `Media/` - User-uploaded files
  - `settings.py` - Project settings
  - `urls.py` - URL routing

## Usage

1. **Menu Management**: Add, edit, or remove menu items through the admin panel
2. **Table Booking**: Customers can book tables through the website
3. **Feedback**: Collect customer feedback through the feedback form

## Troubleshooting

If static files are not loading correctly:
1. Make sure DEBUG is set to True in settings.py
2. Run `python manage.py collectstatic`
3. Check that STATICFILES_DIRS in settings.py points to the correct directory

## License

This project is licensed under the MIT License. #   m y _ r e s t a u r a n t  
 